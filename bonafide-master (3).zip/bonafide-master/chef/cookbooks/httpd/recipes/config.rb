template '/d01/apache/conf/httpd.conf' do
  source 'httpd.conf.erb'
end
