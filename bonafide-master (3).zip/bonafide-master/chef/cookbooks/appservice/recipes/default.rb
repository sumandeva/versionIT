#
# Cookbook:: appservice
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.
