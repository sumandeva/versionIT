package 'tomcat' do 
	action :install
end
