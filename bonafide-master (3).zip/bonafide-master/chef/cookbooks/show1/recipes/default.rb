#
# Cookbook:: show1
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

package 'gcc' do 
	action :install
end
