

package 'mariadb' do 
	action :install
end
