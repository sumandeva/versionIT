
package 'mariadb-server' do 
	action :install
end
