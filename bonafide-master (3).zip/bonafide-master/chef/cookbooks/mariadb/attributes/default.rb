
default['server_pack_name']='mariadb-server'
default['client_pack_name']='mariadb'
default['service_name']='mariadb'
