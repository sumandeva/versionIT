file '/tmp/demo' do 
	action :create
end
