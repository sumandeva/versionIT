#!/bin/bash

## Take input from user
read -p 'Enter Student Name: ' student_name

echo "Hello $student_name , Welcome to VersionIT"
