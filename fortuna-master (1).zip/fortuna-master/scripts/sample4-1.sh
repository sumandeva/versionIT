#!/bin/bash

### Print Some messages
echo "Raju is second standard student"
echo "Raju achived 45% marks"
echo "Raju is not promoted is next standard"
