#!/bin/bash

## Single echo command with multipl elines
echo -e "Rama is second standard student\nRama achived 70% marks\nRama is promoted is next standard"
