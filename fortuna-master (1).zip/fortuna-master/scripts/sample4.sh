#!/bin/bash

studnet_name=Rahim
echo "$studnet_name is second standard student"
echo "$studnet_name achived 70% marks"
echo "$studnet_name is promoted is next standard"
