#!/bin/python

print "Hello World"
