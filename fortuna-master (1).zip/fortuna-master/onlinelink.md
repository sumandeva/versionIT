-----------------------------------------------
THIS IS OLD LINK, DONT JOIN THIS LINK. NEW LINK IS GIVEN BELOW
-----------------------------------------------

8 AM Raghu DevOps

Please join my meeting from your computer, tablet or smartphone.
https://global.gotomeeting.com/join/166133477

You can also dial in using your phone.
United States: +1 (224) 501-3412

Access Code: 166-133-477

First GoToMeeting? Try a test session: https://care.citrixonline.com/g2m/getready


=====================================================================================
# JOIN THIS LINK.
---------------------------------------------------
DevOps - Fortuna

Please join my meeting from your computer, tablet or smartphone.
https://global.gotomeeting.com/join/913417397

You can also dial in using your phone.
United States: +1 (571) 317-3122

Access Code: 913-417-397

First GoToMeeting? Try a test session: https://care.citrixonline.com/g2m/getready
----------------------------------------------------
